import { Auction1CompletedPage } from './app.po';

describe('auction1-completed App', () => {
  let page: Auction1CompletedPage;

  beforeEach(() => {
    page = new Auction1CompletedPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
