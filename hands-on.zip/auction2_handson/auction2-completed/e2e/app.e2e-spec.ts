import { Auction2CompletedPage } from './app.po';

describe('auction2-completed App', () => {
  let page: Auction2CompletedPage;

  beforeEach(() => {
    page = new Auction2CompletedPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
