/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { StarsComponent } from './stars.component';

describe('Component: Stars', () => {
  it('should create an instance', () => {
    let component = new StarsComponent();
    expect(component).toBeTruthy();
  });
});
